package com.company;

public class Main {

    public static void main(String[] args) {
        int[] cj = new int[]{1,1,1,1,1,1};
        int[] tempCj = new int[]{1,1,1,1,1,1};

        Job[] jopTabelle = new Job[]{
                new Job(1, 4, 11),
                new Job(2, 3, 9),
                new Job(3, 2, 7),
                new Job(4, 3, 20),
                new Job(5, 5, 10),
                new Job(6, 6, 5),
        };



    }
}
