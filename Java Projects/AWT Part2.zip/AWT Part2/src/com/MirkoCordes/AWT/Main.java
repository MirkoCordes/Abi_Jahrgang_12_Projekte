package com.MirkoCordes.AWT;

import com.MirkoCordes.AWT.ui.UINotepad;

public class Main {

    public static void main(String[] args) {
        UINotepad.showWindow();
    }
}
