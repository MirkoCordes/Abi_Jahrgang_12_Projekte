package com.MirkoCordes.AWT;

public class Main {

    public static void main(String[] args) {
        AWTWindowTest test_fenster = new AWTWindowTest();
        test_fenster.setVisible(true);
    }
}
