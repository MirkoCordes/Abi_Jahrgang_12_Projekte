package com.company.MirkoCordes;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Ampel[] ampeln = new Ampel[4];
        AmpelPlaner Ap = new AmpelPlaner();
    }
}
