package com.MirkoCordes.AWTKleinprojekt;

public class Main {

    public static void main(String[] args) {
        InfoInterface infoblatt = new InfoInterface();
        infoblatt.setVisible(true);
    }
}
