package com.MirkoCordes.OOP;

public class Subklasse extends Superklasse{

    public Subklasse(int zahlA, int zahlB, int zahlC) {

        super(zahlA, zahlB, zahlC);
    }
}
