package com.MirkoCordes.OOP;

public class Superklasse {
    protected int zahlA;
    public int zahlB;
    private int zahlC;

    public Superklasse(int zahlA, int zahlB, int zahlC) {
        this.zahlA = zahlA;
        this.zahlB = zahlB;
        this.zahlC = zahlC;
    }
}
