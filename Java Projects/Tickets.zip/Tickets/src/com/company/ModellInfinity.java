package com.company;

public class ModellInfinity extends Handy {
    public ModellInfinity(int color, int space, int camera, int simCard, int sdCard){
        super(color, space, camera, simCard, sdCard);
    }
}
